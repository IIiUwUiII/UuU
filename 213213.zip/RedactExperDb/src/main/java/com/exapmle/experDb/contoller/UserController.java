package com.exapmle.experDb.contoller;

import com.exapmle.experDb.Service.UserService;
import com.exapmle.experDb.domain.Role;
import com.exapmle.experDb.domain.User;
import com.exapmle.experDb.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.Map;


@Controller
@RequestMapping("/user")
@PreAuthorize("hasAuthority('ADMIN')")
public class UserController {
    @Autowired
    private UserRepository userRepo;

    @Autowired
    private UserService userService;

    @GetMapping
    public String userList(Model model) {
        model.addAttribute("users", userRepo.findAll());

        return "userList";
    }

    @GetMapping("/create")
    public String create(){

        return "create";
    }

    @PostMapping("/create")
    public String addUser(User user, Map<String,Object> model){

        User userFromDb =userRepo.findByUsername(user.getUsername());

        if(userFromDb != null){

            model.put("message", "User not exist!");
            return "create";
        }

        user.setActive(true);
        user.setRoles(Collections.singleton(Role.USER));
        userRepo.save(user);

        return "redirect:/user";
    }

    @GetMapping("/delete/{id}")
    public String deleteEmployee(@PathVariable("id") Long id) {
        userService.deleteEmployee(id);
        return "redirect:/user";
    }

    @GetMapping("/update/{id}")
    public String updateEmployeePage(Model model, @PathVariable("id") Long id) {
        User employee = userService.getEmployee(id);
        model.addAttribute("employee", employee);
        model.addAttribute("isUpdate", true);
        return "update";
    }
    @PostMapping("/update/{id}")
    public String createEmployee(@ModelAttribute("employee") User employee, @PathVariable("id") Long id) {
        userService.updateEmployee(employee, id);
        return "redirect:/user";
    }

}