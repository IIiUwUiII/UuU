package com.exapmle.experDb.repository;

import com.exapmle.experDb.domain.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository <User,Long> {

    User findByUsername(String username);

    void deleteById(Long id);
}
