package com.exapmle.experDb.Service;


import com.exapmle.experDb.domain.User;
import com.exapmle.experDb.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public String deleteEmployee(Long id) {

        userRepository.deleteById(id);
        return "User deleted successfully";
    }

    public User updateEmployee(User employee, Long id) {
        User emp = userRepository.getOne(id);
        emp.setUsername(employee.getUsername());
        emp.setPassword(employee.getPassword());
        emp.setRoles(employee.getRoles());
        return userRepository.save(emp);
    }

    public User getEmployee(Long id) {
        return userRepository.getOne(id);
    }

}
