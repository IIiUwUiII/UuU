package com.exapmle.experDb.repository;

import com.exapmle.experDb.domain.DBExperiment;
import org.springframework.data.repository.CrudRepository;


public interface DBExperimentRepository extends CrudRepository <DBExperiment,Long> {

}
