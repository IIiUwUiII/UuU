package com.exapmle.experDb.contoller;

import com.exapmle.experDb.domain.DBExperiment;
import com.exapmle.experDb.repository.DBExperimentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Map;

@Controller
public class DBController {


    @Autowired
    private DBExperimentRepository dbExperimentRepository;

    @GetMapping("/")
    public String open (Map <String, Object> model){

        return "open";
    }


    @GetMapping("/main")
    public String main (Map <String, Object> model) {

        Iterable <DBExperiment> messages = dbExperimentRepository.findAll();

        model.put("messages", messages);

        return "main";

    }

    @PostMapping("/main")
    public String add(@RequestParam String FirstName,@RequestParam String LastName,@RequestParam String Brigade,@RequestParam String ChemicalSamples,@RequestParam String Experiment, Map <String, Object> model){

        DBExperiment dbExperiment = new DBExperiment(FirstName, LastName, Brigade, ChemicalSamples, Experiment);

        dbExperimentRepository.save(dbExperiment);

        Iterable <DBExperiment> messages = dbExperimentRepository.findAll();

        model.put("messages", messages);

        return "main";
    }

}