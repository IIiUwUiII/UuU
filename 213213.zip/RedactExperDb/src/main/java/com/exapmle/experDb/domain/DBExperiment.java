package com.exapmle.experDb.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class DBExperiment {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    private String FirstName;
    private String LastName;
    private String Brigade;
    private String ChemicalSamples;
    private String Experiment;

    public DBExperiment() {
    }

    public DBExperiment(String firstName, String lastName, String brigade, String chemicalSamples, String experiment) {
        FirstName = firstName;
        LastName = lastName;
        Brigade = brigade;
        ChemicalSamples = chemicalSamples;
        Experiment = experiment;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String firstName) {
        FirstName = firstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String lastName) {
        LastName = lastName;
    }

    public String getBrigade() {
        return Brigade;
    }

    public void setBrigade(String brigade) {
        Brigade = brigade;
    }

    public String getChemicalSamples() {
        return ChemicalSamples;
    }

    public void setChemicalSamples(String chemicalSamples) {
        ChemicalSamples = chemicalSamples;
    }

    public String getExperiment() {
        return Experiment;
    }

    public void setExperiment(String experiment) {
        Experiment = experiment;
    }
}
